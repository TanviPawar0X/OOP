import java.util.*;
public class MyConsole {
	private static Scanner sc=new Scanner(System.in);
	
	public static String getString(String question) {
		
		System.out.println(question);
		return sc.nextLine();
	}
		
		public static int getNumber(String question) {
			System.out.println(question);
			return sc.nextInt();

	}

}
