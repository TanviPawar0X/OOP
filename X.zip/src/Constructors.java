//Constructor special functions that are used to set values for the fields of class so that object that is created can be usable without additional functions to be called before we use it.

import java.util.*;
class Course{
	int courseId;
	String courseName;
	int courseDuration;
	String trainer;
	
	public Course(int id,String name, String trainer, int duration) {
		courseId=id;
		courseName=name;
		this.trainer=trainer;
		courseDuration=duration;
		
	}
}
public class Constructors {
	
	//Encapsulate
  //access modifier returntype funcname(parameters)
	private static Course createCourse() {
		Scanner sc1=new Scanner(System.in);
		int id=MyConsole.getNumber("Enter Course Id");
		
		String name=MyConsole.getString("Enter Course Name");
		sc1.nextLine();
		String trainer=MyConsole.getString("Enter Course Trainer");
		int duration=MyConsole.getNumber("Enter Course duration");
		Course cr = new Course(id,name,trainer,duration);
		return cr;
		
	}

	public static void main(String[] args) {

		int [] example = new int[5];
		
		//this helpful in case of database and populating to an object
		//123
		//Course cr=new Course(123,"Tan","xyz",14);
//		cr.courseId=123;
//		cr.courseDuration=14;
//		cr.courseName="xyz";
//		cr.trainer="Tan"
		//System.out.println(cr.courseId);
		
		//Course cr=Constructors.createCourse();  //another way
		Course cr = createCourse();
		
	}

}
