/*
 * Method in java can have parameters.
 * Parameters are input tobe provided for a method to be invoked properly.
 * 2ways
 * Pass by value:
 * process in which func para values are copied to an another variable and used in func.any change made to variable will not be reflected back to variable after the function has returned .This is the java feature
 * Pass by reference:
 * same variable will be passed 
 * 
 * pass by value->primitive types
 * pass by reference->
 */



class Customer{
	public int cstId;
	public String cstName;
	
	public Customer(int id,String name) {
		cstId=id;
		cstName=name;
	}
}

public class ParametersDemo {

	static void passByValue(int someData) {
		System.out.println("Value passed by function: "+someData);
		someData+=3456;
		System.out.println("Value modified in function: "+someData);
	}
	
	static void passReferenceObject(Customer cst) {
		cst.cstName="Chnaged Name";
	}
	
	public static void main(String[] args) {
		int someData=123;
		
    	passByValue(someData); 
		//Variable is not passed, copy will be passed.
        //So any change u make in func will be applicable only to copy.
        //after coming back from func copy is destroyed...........
		
    	System.out.println("After coming back from function: "+someData);
		
		System.out.println("////////////////////////////////////////");
		
		Customer cst=new Customer(123,"Tan");
		
		passReferenceObject(cst);
		//copy is alias to cst
		//both copy and obj will point to same memory,change will reflect back 
		
		System.out.println("Customer after function call: "+cst.cstName);
		
		Customer copy=cst;
		copy.cstName="Apple123";
		System.out.println(cst.cstName);
	}

}
