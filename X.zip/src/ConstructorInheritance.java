
class Baseclass{

	public Baseclass() {
		System.out.println("base class is created");
	}
	//Paramertise
	public Baseclass(String arg) {
		this();  //One constructor calling the other.................
		System.out.println("base class is created with arg: " +arg);
	}
	public Baseclass(int arg) {
		System.out.println("base class is created with integer arg: " +arg);
	}
}

class Derivedclass extends Baseclass{
	public Derivedclass() {
		super("String arg");
		System.out.println("derived class1 is created");		
	}
	public Derivedclass(String arg) {
		super(123);
		System.out.println("derived class2 is created");		
	}
}

public class ConstructorInheritance {

	public static void main(String[] args) {
		Derivedclass c1 = new Derivedclass();

	}

}
