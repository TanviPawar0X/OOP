/*
 * PTR
 * FI have only one abstract method but can have multiple default methods.
 * @FunctionalInterface annotation used to ensure that it cannot have more than one method in it.
 * it is enforced in Eclispe only
 * This concept was introduced in J-8 and its practical uses available when we use java.util package that has a lot new functional interface:
 * Predicate
 * Comparable
 * BitiwiseOperator
 * Runnable interfaces
 * where when we implement these interface u dont need to create explicit class
 *before j-8 we used inner classes to achive same mechanism
*/



//@FunctionalInterface //optional,this will make interface not accept additional methods....
interface ITest{
	void testFunc();
}

interface MathInterface{
	double mathFunc(double v1,double v2);
}
class Tester implements ITest{
	public void testFunc() {
		System.out.println("An Example");
	}
}
public class FunctionalInterface {

	public static void main(String[] args) {
		//ITest javaTest = () -> System.out.println("An Example");
		ITest javaTest=new Tester();//olf format....
		javaTest.testFunc();

		///////////////////////New way
		ITest jspTst=() -> System.out.println("JSP Test implementation");
		jspTst.testFunc();
		
		////////////////////MathInterface implemented
		MathInterface addFunc=(double v1,double v2)->v1+v2;
		MathInterface subFunc=(double v1,double v2)->v1-v2;
		System.out.println("The added value: " +addFunc.mathFunc(500,476));
		System.out.println("The added value: " +subFunc.mathFunc(500,476));
	}

}
