import java.util.Scanner;

/*
 * when u have a base and a derived class, 
 * it is possible to create an object of the base class and inheritance
 * it to the derived class.
 * This is based on Liskov's Substitution principle.
 * in this case the numbers of the base class can be accessed thru' the object
 * 
 * 
 *Modifying a class can be done in 2 ways: Add a new feature or modify an existing feature
 *An Existing function can redefined to suit the new requirement of UR
 * application. In this case, U would redefine the function in the 
 * derived class without altering the signature of function. 
 *This is called Method OVERRIDING.
 */

class FatherBusiness{
	void MakePayment(String mode,int amount) {
		if((mode=="Cash")||(mode=="Cheque"))
		{
			System.out.println(String.format("An Amount of Rs.%d is payed in form of %s", amount,mode));		
		}
		else {
			System.out.println("Invalid mode of payment, not Accepted");
			
		}
	}
}
class SonBusiness extends FatherBusiness{
	void MakePayment(String mode,int amount) {
		//Method overriding is redefining the base class method in derived to suit the new or modified requirement of the application
		if((mode=="Cash")||(mode=="Card"))
		{
			System.out.println(String.format("An Amount of Rs.%d is payed in form of %s", amount,mode));		
		}
		else {
			System.out.println("Invalid mode of payment, not Accepted");
			
		}
	}
}

class BusinessFactory{
	public static FatherBusiness getOwner(String name) {
		if(name.equals("Father"))
			return new FatherBusiness();
		else
			return new SonBusiness();
	}
}
public class MethodOverridingExample {
	public static void main(String[] args) {
		
		System.out.println("Enter.....");
		Scanner sn=new Scanner(System.in);
		String name=sn.nextLine();
		FatherBusiness customer=BusinessFactory.getOwner(name);
		//FatherBusiness customer=new FatherBusiness();
		customer.MakePayment("Cheque", 50000);
		
		customer=new SonBusiness();
		customer.MakePayment("Cheque", 45000);
		/*Polymorphism:feature of OOP where an object and its method could behave 
		in different way based on a different conditions
		*/
	}
}
