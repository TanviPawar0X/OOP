/*
 * All OOP features are on 
 * S:Single Responsibility principle:Layered Architecture.
 * O:Open Closed Principle: Inheritance feature is because of this.
 * L:Luskov's Substitution Principle:Runtime Polymorphism
 * I:Interface Segregation Principle: Dividing ur code into concrete interfaces
 * D:Dependency Inversion Principle: ur function should return abstract objects rather than concrete objects.
 * 
 *open closed principle states that a class is closed for modification but its open for extension. 
 *
 *
 *A class function can be extended to other classess in OOP
 *the class that is being extended is called BASE(Parent,Super)class 
 *and the class that is extending is calles DERIVED (Child,Sub)class
 *Java supports single inheritance.
 *ur class can have only one base class at a given level
 *however java supports multi level inheritance where a class can be extended 
 *to another and that to another and do forth...
 */

//what is JAR?
//Reusability 

class BaseClass{
	public static void testFunc()
	{
		System.out.println("Test Program");
	}
}
class DerivedClass extends BaseClass{
	public static void newFunc()
	{
		System.out.println("New Functionality");
	}
}
class InheritanceDemo{
	public static void main(String[] args)
	{
		DerivedClass obj=new DerivedClass();
		obj.testFunc();
		obj.newFunc();
	}
}
/*
class Account{
	int accNo;
	String holderName;
	int balance;
	void Credit(int amount) {
		balance+=amount;
	}
	void Debit(int amount) {
		if(amount <=balance)
		{
			balance-=amount;
		}
	}
}	
class SBAccount extends Account{
	void CalculateInterest() {
		int principle=balance;
		double term=1/4;
		double rate=6.5/100;
		double interest=principle*term*rate;
		Credit((int)interest);
	}
}
public class InheritanceDemo {
	public static void main(String[] args)
	{
		SBAccount acc=new SBAccount();
		acc.accNo=123;
		acc.holderName="Tan";
		acc.Credit(65000);
		
		acc.CalculateInterest();
		System.out.println("The Balance: "+ acc.balance);
	}
}*/
