
public class ClassesDemo {
	public static void main(String[] args) {
		Student student = new Student();
		student.setDetails(123, "Tan", "Navi Mumbai");
		System.out.println("The ID is "+student.getId());
		System.out.println("The Name is "+student.getName());
		System.out.println("The Location is "+student.getLocation());
	}

}
//every class have data, function, nested classes....
//Encapsulation-feature of oops to hide members u dont want to show to the members
//However u create them for storing data, modularity reasons...
class Student{
	//data will be usually private.It is hidden to others.
	//id name location are fields of the class..
	private int id;
	private String name;
	private String location;
//function or methods are operations are performed by the object..
//operations are created to either access the private members or to manipulate them.
	void setDetails(int id, String name, String location) {
		this.id=id;//this is an operator used within a class to refer its members..
		this.name=name;
		this.location=location;
	}
	int getId()
	{
		return id;
	}
	String getName() {
		return name;
	}
	String getLocation() {
		return location;
	/*String getAllDetails(){
	 return String.format("Id: %d "+"Name: %s"+"Location: %s");
	 */
	}
	}
//create a Class called CDACCenter 
//id name location address coodinator.
//develop an app that will take input from the user to create objects of centers an location to be in bangalore pune mumbai hyderbad chennai 
//create array of center of size 5. allow user to set the values to these centers and then display the details on the console..
