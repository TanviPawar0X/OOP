
class ArrayExample {
	public static void main(String[] args)
	{
		String[] fruits=new String[5];
		for(int i=0;i<5;i++)
		{
			fruits[i]=IOClass.getString("Enter the fruit Name");
		}
		System.out.println("All the fruits have been set");
		System.out.println("Display all fruits:");
		for(String fruit:fruits) {
			System.out.println(fruit);
		}
	}

}
