class Calculator {
   public static void main(String[] args)
   {
	  boolean check =true;
	  do {
	  double value1=IOClass.getDouble("Enter the First Value");
	  double value2=IOClass.getDouble("Enter the Second Value");
	  String operand=IOClass.getString("Enter the Operation as: + - * /");
	  double result=getResult(value1,value2,operand);
	  System.out.println("The Result of this Operation is :"+result);
	  check=IOClass.getBoolean("Do you want to try again? Please Y or N");
	  }while(check);
   }
   static double getResult(double value1,double value2,String operand)
   {
	   double result=0;
	   switch(operand)
	   {
	   case "+":
		   result=value1 + value2;
		   break;
	   case "-":
		   result=value1 - value2;
		   break;
	   case "*":
		   result=value1 * value2;
		   break;
	   case "/":
		   result=value1 / value2;
		   break;
	   default:
		   result=0;
		   break;
	   }
	   return result;
   }
}
class IOClass
{
	static String getString(String question)
	{
		System.out.println(question);
		return System.console().readLine();
	}
	static double getDouble(String question) {
		System.out.println(question);
		String answer=System.console().readLine();
		return Double.parseDouble(answer);
	}
	static boolean getBoolean(String question)
	{
		System.out.println(question);
		String answer=System.console().readLine();
		//return Boolean.parseBoolean(answer);
		return answer.equals("Y");//checks for true or false
		//== doesn't work for String reference
	}
}