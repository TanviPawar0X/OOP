


/*abstract class Test
{
	void testExample() 
	{
		System.out.println("test Example implemented");
	}
	
	public abstract void testFunc();
}

class SubTest extends Test
{
	public void testFunc() 
	{
		System.out.println("test func is implemented in the subclass");
	}
}*/

//abstract class Account{
//	int accNo;
//	String name;
//	int balance;
//	
//	public void credit(int amount) {balance+=amount;}
//	
//	public void debit(int amount) {balance-=amount;}
//	
//	public abstract void CalculateInterest();
//}
//class TPAccount extends Account{
//	
//	public void CalculateInterest() {
//		int p=this.balance;
//		double rate=6.5/100;
//		double term=0.25;
//		double interest=p*rate*term;
//		balance+=(int)interest;
//	}
//}
//
//public class AbstractClasses 
//{
//	public static void main(String[] args)
//	{
//		/*Test t=new SubTest();
//		t.testExample();
//		t.testFunc();*/
//		
//		Account acc=new TPAccount();
//		acc.accNo=11;
//		acc.balance=650000;
//		acc.name="Tan";
//		acc.credit(5000);
//		acc.CalculateInterest();
//		System.out.println("The balance: "+acc.balance);
//	}
//
//}



abstract class Account{
	int accNo;
	String name;
	int balance;
	
	public void credit(int amount) {balance+=amount;}
	
	public void debit(int amount) {balance-=amount;}
	
	public abstract void CalculateInterest();
}
class TPAccount extends Account{
	
	public void CalculateInterest() {
		int p=this.balance;
		double rate=6.5/100;
		double term=0.25;
		double interest=p*rate*term;
		balance+=(int)interest;
	}
}

class SBAccount extends Account{
	public void CalculateInterest() {
		
	}
}

class FDAccount extends Account{
	public void CalculateInterest() {
		
	}
}

public class AbstractClasses 
{
	public static void main(String[] args)
	{	
		String input=MyConsole.getString("Enter type of account: TP, SB,  OR FD");
		Account acc=null;
		switch(input)
		{
		case "TP":
			acc=new TPAccount();
			break;
		case "SB":
			acc=new SBAccount();
			break;
		case "FD":
			acc=new FDAccount();
			break;
		}
		acc.accNo=11;
		acc.balance=650000;
		acc.name="Tan";
		acc.credit(5000);
		acc.CalculateInterest();
		System.out.println("The balance: "+acc.balance);
	}

}