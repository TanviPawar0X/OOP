//Access specifiers in Java is available for feature of encapsulation also called data hiding.
//u can determine the scope of ur data within ur Applications
//encapsulation also help in creating business rules within the application

//4 access specifier are available

//deafult: makes members of class accessible within package(unit) of the application

//private: allow members to accessible within the declared class only.most secured.

//public: available across class packages application also

//protected: allows to be accessible within the declared class and its inherited classes.
class Example{
	//available anywhere..........
	public void publicFunc() 
	{
		privateFunc();
		System.out.println("Public Function");
	}
	
	//only within the class.....
	private void privateFunc() {
		System.out.println("Private Function");
		}
	
	//available in current group(Package).....
	void defaultFunc() {
		System.out.println("default Function");
		}
	
	//only here or in derived classes.....
	protected void protectedFunc() {
		System.out.println("protected Function");
		}
}
public class AccessSpecifiersDemo {

	public static void main(String[] args) {
		Example test;
		test=new Example();//creating an object of the class
		//Object is nothing but a refernce vairable with memory allocated to it
		test.defaultFunc();
		test.publicFunc();
		test.protectedFunc();

	}

}
