import java.util.Scanner;

/*create a func that takes array as args and
 * it should return sum of elements in array.
 * 
 */
/*
 * public class Practise {

	Scanner sc=new Scanner(System.in);
	int[] arr=new int[5];
	void setArray()
	{
		
		for(int i=0;i<5;i++)
		{
			arr[i]=sc.nextInt();
		}
	}
	
	int getSum()
	{
		int sum=0;
		for(int j=0;j<5;j++)
		{
			sum=sum+arr[j];
		}
		return sum;
	}
	public static void main(String[] args) {
		Practise call=new Practise();
		call.setArray();
		System.out.println(call.getSum());

	}

}*/

public class Practise {

	static int getSum(int[] values)
	{
		int sum=0;
		for(int num:values)
			sum+=num;
		return sum;
	}
	public static void main(String[] args) {
		int res=getSum(new int[] {1,2,3,4});
		System.out.println(res);

	}

}
