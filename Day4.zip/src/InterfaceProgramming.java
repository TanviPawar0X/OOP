

//interface MyWish{
//	void CreateHouse();
//	void BuyCar();
//}
//
//class WishImplementor implements MyWish{
//	
//	public void CreateHouse() {
//		
//	}
//	public void BuyCar() {
//		
//	}
//}
//public class InterfaceProgramming {
//
//	public static void main(String[] args) {
//		MyWish dreams=new WishImplementor();
//		dreams.CreateHouse();
//		dreams.BuyCar();
//
//	}
//
//}

interface IParty{
	void InviteFriends(String[] names);
	void OrderCake(int size,String flavour);
	default void OrderDrinks() {
		System.out.print("Soft Drinks are ordered" );
	}
}

class Party implements IParty{
	
	@Override
	public void InviteFriends(String[] names) {
		for(String name: names)
			System.out.println("Sending whatsapp message to invite to "+name);
	}
	
    public void OrderCake(int size,String flavour) {
			System.out.println("Ordered cake from cakeshop and slices weight "+size+" and flavour "+flavour);
		
	}
}
class MyPersonalParty implements IParty{
	
	@Override
	public void InviteFriends(String[] names) {
			System.out.println("Invited personally");
	}
	
    public void OrderCake(int size,String flavour) {
			System.out.println("Orders veg cake");
		
	}
}

public class InterfaceProgramming {

	public static void main(String[] args) {
		IParty party=new Party();
		party.InviteFriends(new String[] {"tin","tan","tim","tab"});
		party.OrderCake(4,"Mango");

		party=new MyPersonalParty();
		party.InviteFriends(new String[] {"tin","tan","tim","tab"});
		party.OrderCake(4,"Pineapple");
	}
}
	
	
	
	
	
	
	