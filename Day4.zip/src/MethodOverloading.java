import java.util.*;

class Employee
{
	int empId;
	String empName;
	
	void setDetails(int id,String name) {
		empId=id;
		empName=name;	
	}
}

class EmployeeDb{
	private Employee [] employees=new Employee[5];
	
	public void setValues() {
		//for(int i=0;i<10;i++) {}
			employees[0]=new Employee();
			employees[0].setDetails(111, "tin");
			
			employees[1]=new Employee();
			employees[1].setDetails(112, "tan");
			
			employees[2]=new Employee();
			employees[2].setDetails(113, "tam");
			
			employees[3]=new Employee();
			employees[3].setDetails(114, "tim");
			
			employees[4]=new Employee();
			employees[4].setDetails(115, "tab");
		
	}
	
	/*foreach does not need to know the max no.of element, u dont have to increm. any number ,index value need 
	not  be evaluated. easy for iterating purpose 
	*/
	public Employee FindEmp(int id) {
		for(Employee employee : employees) 
		{
			if(employee.empId == id) 
			{
				return employee;
			}
		}
		return null;//if no employee found 
	}
	
	//public Employee[] FindEmp(String name) {}
	public List<Employee> FindEmp(String name)
	{
		ArrayList<Employee> list=new ArrayList<Employee>();
	    
		for(Employee emp : employees) 
		{
		   if(emp.empName.contains(name)) 
		   {
			list.add(emp);
		   }
	    }
		return list;
	}
}

public class MethodOverloading 
{

	/*public static void testfunc() {
		System.out.println("test");
	}
	public static void testfunc(int x) {
		System.out.println("test"+x);
	}*/
	
	public static void main(String[] args) 
	{
		EmployeeDb db=new EmployeeDb();
		db.setValues();
		
		Employee emp=db.FindEmp(112);
		System.out.println(emp.empName);
		
		List<Employee> foundEmployee=db.FindEmp("tin");
		foundEmployee.forEach((eemp)->System.out.println(eemp.empId));
			
		}
}
